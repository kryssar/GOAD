#Region '.\prefix.ps1' -1

using module .\Modules\DscResource.Base

$script:dscResourceCommonModulePath = Join-Path -Path $PSScriptRoot -ChildPath 'Modules/DscResource.Common'
Import-Module -Name $script:dscResourceCommonModulePath

$script:computerManagementDscCommonModulePath = Join-Path -Path $PSScriptRoot -ChildPath 'Modules/ComputerManagementDsc.Common'
Import-Module -Name $script:computerManagementDscCommonModulePath

$script:localizedData = Get-LocalizedData -DefaultUICulture 'en-US'
#EndRegion '.\prefix.ps1' 10
#Region '.\Classes\001.CMReason.ps1' -1

<#
    .SYNOPSIS
        The reason a property of a DSC resource is not in desired state.

    .DESCRIPTION
        A DSC resource can have a read-only property `Reasons` that the compliance
        part (audit via Azure Policy) of Azure AutoManage Machine Configuration
        uses. The property Reasons holds an array of CMReason. Each CMReason
        explains why a property of a DSC resource is not in desired state.
#>

class CMReason
{
    [DscProperty()]
    [System.String]
    $Code

    [DscProperty()]
    [System.String]
    $Phrase
}
#EndRegion '.\Classes\001.CMReason.ps1' 22
#Region '.\Classes\020.PSResourceRepository.ps1' -1

<#
    .SYNOPSIS
        A class for configuring PowerShell Repositories.

    .PARAMETER Ensure
        If the repository should be present or absent on the server
        being configured. Default values is 'Present'.

    .PARAMETER Name
        Specifies the name of the repository to manage.

    .PARAMETER SourceLocation
        Specifies the URI for discovering and installing modules from
        this repository. A URI can be a NuGet server feed, HTTP, HTTPS,
        FTP or file location.

    .PARAMETER Credential
        Specifies credentials of an account that has rights to register a repository.

    .PARAMETER ScriptSourceLocation
        Specifies the URI for the script source location.

    .PARAMETER PublishLocation
        Specifies the URI of the publish location. For example, for
        NuGet-based repositories, the publish location is similar
        to http://someNuGetUrl.com/api/v2/Packages.

    .PARAMETER ScriptPublishLocation
        Specifies the URI for the script publish location.

    .PARAMETER Proxy
        Specifies the URI of the proxy to connect to this PSResourceRepository.

    .PARAMETER ProxyCredential
        Specifies the Credential to connect to the PSResourceRepository proxy.

    .PARAMETER InstallationPolicy
        Specifies the installation policy. Valid values are  'Trusted'
        or 'Untrusted'. The default value is 'Untrusted'.

    .PARAMETER PackageManagementProvider
        Specifies a OneGet package provider. Default value is 'NuGet'.

    .PARAMETER Default
        Specifies whether to set the default properties for the default PSGallery PSRepository.
        Default may only be used in conjunction with a PSRepositoryResource named PSGallery.
        The properties SourceLocation, ScriptSourceLocation, PublishLocation, ScriptPublishLocation, Credential,
        and PackageManagementProvider may not be used in conjunction with Default.
        When the Default parameter is used, properties are not enforced when PSGallery properties are changed outside of Dsc.

    .PARAMETER Reasons
        Returns the reason a property is not in desired state.

    .EXAMPLE
        Invoke-DscResource -ModuleName ComputerManagementDsc -Name PSResourceRepository -Method Get -Property @{
            Name                      = 'PSTestRepository'
            SourceLocation            = 'https://www.nuget.org/api/v2'
            ScriptSourceLocation      = 'https://www.nuget.org/api/v2/package/'
            PublishLocation           = 'https://www.nuget.org/api/v2/items/psscript/'
            ScriptPublishLocation     = 'https://www.nuget.org/api/v2/package/'
            InstallationPolicy        = 'Trusted'
            PackageManagementProvider = 'NuGet'
        }
        This example shows how to call the resource using Invoke-DscResource.
#>
[DscResource()]
class PSResourceRepository : ResourceBase
{
    [DscProperty()]
    [Ensure]
    $Ensure = [Ensure]::Present

    [DscProperty(Key)]
    [System.String]
    $Name

    [DscProperty()]
    [System.String]
    $SourceLocation

    [DscProperty()]
    [PSCredential]
    $Credential

    [DscProperty()]
    [System.String]
    $ScriptSourceLocation

    [DscProperty()]
    [System.String]
    $PublishLocation

    [DscProperty()]
    [System.String]
    $ScriptPublishLocation

    [DscProperty()]
    [System.String]
    $Proxy

    [DscProperty()]
    [PSCredential]
    $ProxyCredential

    [DscProperty()]
    [ValidateSet('Untrusted', 'Trusted')]
    [System.String]
    $InstallationPolicy

    [DscProperty()]
    [System.String]
    $PackageManagementProvider

    [DscProperty()]
    [Nullable[System.Boolean]]
    $Default

    [DscProperty(NotConfigurable)]
    [CMReason[]]
    $Reasons

    # Passing the module's base directory to the base constructor so it finds localization files.
    PSResourceRepository () : base ($PSScriptRoot)
    {
        # These properties will not be enforced.
        $this.ExcludeDscProperties = @(
            'Name',
            'Default'
        )
    }

    [PSResourceRepository] Get()
    {
        return ([ResourceBase] $this).Get()
    }

    [void] Set()
    {
        ([ResourceBase] $this).Set()
    }

    [Boolean] Test()
    {
        return ([ResourceBase] $this).Test()
    }

    hidden [void] Modify([System.Collections.Hashtable] $properties)
    {
        $params = @{
            Name = $this.Name
        }

        if ($properties.ContainsKey('Ensure') -and $properties.Ensure -eq 'Absent' -and $this.Ensure -eq 'Absent')
        {
            # Ensure was not in desired state so the repository should be removed
            Write-Verbose -Message ($this.localizedData.RemoveExistingRepository -f $this.Name)

            Unregister-PSRepository @params

            return
        }
        elseif ($properties.ContainsKey('Ensure') -and $properties.Ensure -eq 'Present' -and $this.Ensure -eq 'Present')
        {
            # Ensure was not in desired state so the repository should be created
            $register = $true

        }
        else
        {
            # Repository exist but one or more properties are not in desired state
            $register = $false
        }

        foreach ($key in $properties.Keys.Where({ $_ -ne 'Ensure' }))
        {
            $params[$key] = $properties.$key
        }

        if ($register)
        {
            if ($this.Name -eq 'PSGallery')
            {
                Write-Verbose -Message ($this.localizedData.RegisterDefaultRepository -f $this.Name)

                Register-PSRepository -Default

                #* The user may have specified Proxy & Proxy Credential, or InstallationPolicy params
                Set-PSRepository @params
            }
            else
            {
                if ([System.String]::IsNullOrEmpty($this.SourceLocation))
                {
                    $errorMessage = $this.LocalizedData.SourceLocationRequiredForRegistration

                    New-ArgumentException -ArgumentName 'SourceLocation' -Message $errorMessage
                }

                if ($params.Keys -notcontains 'SourceLocation')
                {
                    $params['SourceLocation'] = $this.SourceLocation
                }

                Write-Verbose -Message ($this.localizedData.RegisterRepository -f $this.Name, $this.SourceLocation)

                Register-PSRepository @params
            }
        }
        else
        {
            Write-Verbose -Message ($this.localizedData.UpdateRepository -f $this.Name, $this.SourceLocation)

            Set-PSRepository @params
        }
    }

    hidden [System.Collections.Hashtable] GetCurrentState ([System.Collections.Hashtable] $properties)
    {
        $returnValue = @{
            Ensure = [Ensure]::Absent
            Name   = $this.Name
        }

        Write-Verbose -Message ($this.localizedData.GetTargetResourceMessage -f $this.Name)

        $repository = Get-PSRepository -Name $this.Name -ErrorAction SilentlyContinue

        if ($repository)
        {
            $returnValue.Ensure                    = [Ensure]::Present
            $returnValue.SourceLocation            = $repository.SourceLocation
            $returnValue.ScriptSourceLocation      = $repository.ScriptSourceLocation
            $returnValue.PublishLocation           = $repository.PublishLocation
            $returnValue.ScriptPublishLocation     = $repository.ScriptPublishLocation
            $returnValue.Proxy                     = $repository.Proxy
            $returnValue.ProxyCredential           = $repository.ProxyCredential
            $returnValue.InstallationPolicy        = $repository.InstallationPolicy
            $returnValue.PackageManagementProvider = $repository.PackageManagementProvider
        }
        else
        {
            Write-Verbose -Message ($this.localizedData.RepositoryNotFound -f $this.Name)
        }

        return $returnValue
    }

    <#
        The parameter properties will contain the properties that was
        assigned a value.
    #>
    hidden [void] AssertProperties([System.Collections.Hashtable] $properties)
    {
        Assert-Module -ModuleName PowerShellGet
        Assert-Module -ModuleName PackageManagement

        $assertBoundParameterParameters = @{
            BoundParameterList = $properties
            MutuallyExclusiveList1 = @(
                'Default'
            )
            MutuallyExclusiveList2 = @(
                'SourceLocation'
                'PackageSourceLocation'
                'ScriptPublishLocation'
                'ScriptSourceLocation'
                'Credential'
                'PackageManagementProvider'
            )
        }

        Assert-BoundParameter @assertBoundParameterParameters

        if ($this.Name -eq 'PSGallery')
        {
            if (-not $this.Default -and $this.Ensure -eq 'Present')
            {
                $errorMessage = $this.localizedData.NoDefaultSettingsPSGallery

                New-ArgumentException -ArgumentName 'Default' -Message $errorMessage
            }
        }
        else
        {
            if ($this.Default)
            {
                $errorMessage = $this.localizedData.DefaultSettingsNoPSGallery

                New-ArgumentException -ArgumentName 'Default' -Message $errorMessage
            }
        }

        if ($this.ProxyCredential -and (-not $this.Proxy))
        {
            $errorMessage = $this.localizedData.ProxyCredentialPassedWithoutProxyUri

            New-ArgumentException -ArgumentName 'ProxyCredential' -Message $errorMessage
        }
    }
}
#EndRegion '.\Classes\020.PSResourceRepository.ps1' 301
